This directory contains various generic C++ support code shared between the Nginx module, Apache module and the Passenger agent.

Code in `vendor-copy` and `vendor-modified` came from third parties.
